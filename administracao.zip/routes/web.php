<?php

use App\Http\Controllers\StudentController;
use App\Http\Controllers\ActivitisController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DashboardController;

Route::get('/', [AuthController::class, 'dashboard']);
Route::post('post-teacher-form', [TeacherController::class, 'store']);
Route::get('create-teacher', [TeacherController::class, 'create']);
Route::get('all-teacher', [TeacherController::class, 'index']);
Route::get('edit-teacher/{id}', [TeacherController::class, 'edit']);
Route::post('update-teacher/{id}', [TeacherController::class, 'update']);
Route::get('delete-teacher/{id}', [TeacherController::class, 'destroy']);
Route::get('get-activity-form', [ActivitisController::class, 'create']);
Route::post('post-activity-form', [ActivitisController::class, 'store']);
Route::get('all-activity', [ActivitisController::class, 'index']);
Route::get('edit-activity/{id}', [ActivitisController::class, 'edit']);
Route::post('post-activity-edit-form/{id}', [ActivitisController::class, 'update']);
Route::get('delete-activity/{id}', [ActivitisController::class, 'destroy'])->name('delete.activity');
Route::get('get-student-form', [StudentController::class, 'create']);
Route::post('post-student-form', [StudentController::class, 'store']);
Route::get('all-students', [StudentController::class, 'index']);
Route::get('edit-student/{id}', [StudentController::class, 'edit']);
Route::post('post-student-edit-form/{id}', [StudentController::class, 'update']);
Route::get('delete-student/{id}', [StudentController::class, 'destroy']);



Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('custom-login', [AuthController::class, 'customLogin'])->name('login.custom');
Route::get('registration', [AuthController::class, 'registration'])->name('register-user');
Route::post('custom-registration', [AuthController::class, 'customRegistration'])->name('register.custom');
Route::get('signout', [AuthController::class, 'signOut'])->name('signout');
