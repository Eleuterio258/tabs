<?php $__env->startSection('titolo', 'Dashboard.'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">All Categoriest</li>
            </ol>
        </nav>


        <?php if(Session::get('deleted')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="gone">
                <strong> <?php echo e(Session::get('deleted')); ?> </strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(Session::get('delete-failed')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert" id="gone">
                <strong> <?php echo e(Session::get('delete-failed')); ?> </strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="card mb-3">

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table  table-bordered table-striped ">
                        <thead>
                            <tr>
                                <th>Title </th>
                                <th>Message </th>
                                <th>Image </th>
                                <th>Actions </th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($slider->title); ?> </td>
                                    <td> <?php echo $slider->message; ?> </td>
                                    <td> <img src="<?php echo e($slider->image_url); ?>" class="pro-img"></td>
                                    <td>
                                        <a href="<?php echo e(URL::to('edit-slider')); ?>/<?php echo e($slider->id); ?>"
                                            class="btn btn-primary btn-sm"> Edit </a>
                                        |
                                        <a href="<?php echo e(URL::to('delete-slider')); ?>/<?php echo e($slider->id); ?>"
                                            class="btn btn-danger btn-sm" onclick="checkDelete()"> Delete </a>
                                    </td>

                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        function checkDelete() {
            var check = confirm('Are you sure you want to Delete this?');
            if (check) {
                return true;
            }
            return false;
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/slider/index.blade.php ENDPATH**/ ?>