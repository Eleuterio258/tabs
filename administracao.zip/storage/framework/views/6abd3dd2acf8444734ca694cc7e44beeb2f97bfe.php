<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2021</span>
        </div>
    </div>
</footer>
<!-- End of Footer --><?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/templete/footer.blade.php ENDPATH**/ ?>