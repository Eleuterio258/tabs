<?php $__env->startSection('titolo', 'Dashboard.'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="dashboard">

            <div id="painel">
                <i class="fa fa-user"></i>
                <p>
                    <strong>Users</strong><br>
                    <span>33</span>
                </p>
            </div>

            <div id="painel">
                <i class="fas fa-users"></i>
                <p>
                    <strong>Custumers</strong><br>
                    <span>55</span>
                </p>
            </div>

            <div id="painel">
                <i class="fas fa-boxes"></i>
                <p>
                    <strong>Products</strong><br>
                    <span>5</span>
                </p>
            </div>
            <div id="painel">
                <i class="fas fa-coins"></i>
                <p>
                    <strong>Providers</strong><br>
                    <span>12</span>
                </p>
            </div>
            <div id="painel">
                <i class="fas fa-coins"></i>
                <p>
                    <strong>Orders</strong><br>
                    <span>12</span>
                </p>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Php\www\2021\2-ABR\administracao\resources\views/dashboard.blade.php ENDPATH**/ ?>