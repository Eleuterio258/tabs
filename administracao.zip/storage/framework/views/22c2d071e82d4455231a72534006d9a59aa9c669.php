<?php $__env->startSection('titolo', 'Dashboard.'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="dashboard">

        <div id="painel">
            <i class="fa fa-user"></i>
            <p>
                <strong>Teacher</strong><br>
                <span>12</span>
            </p>
        </div>

        <div id="painel">
            <i class="fas fa-users"></i>
            <p>
                <strong>Student</strong><br>
                <span>12</span>
            </p>
        </div>

        <div id="painel">
            <i class="fas fa-boxes"></i>
            <p>
                <strong>Activities</strong><br>
                <span>12</span>
            </p>
        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/dashboard.blade.php ENDPATH**/ ?>