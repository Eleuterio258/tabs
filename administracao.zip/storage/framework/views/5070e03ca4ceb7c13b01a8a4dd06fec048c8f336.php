<script src="<?php echo 'public/vendor/jquery/jquery.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/jquery-easing/jquery.easing.min.js'; ?> "></script>
<script src="<?php echo 'public/js/sb-admin-2.min.js'; ?> ?>"></script>
<script src="<?php echo 'public/vendor/bootstrap/js/bootstrap.bundle.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/jquery.dataTables.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/dataTables.bootstrap4.min.js'; ?> "></script>
<script src="<?php echo 'public/js/demo/datatables-demo.js'; ?>"></script>
<?php /**PATH E:\projectos\Programacao\Php\www\2021\2-ABR\administracao\resources\views/templete/script.blade.php ENDPATH**/ ?>