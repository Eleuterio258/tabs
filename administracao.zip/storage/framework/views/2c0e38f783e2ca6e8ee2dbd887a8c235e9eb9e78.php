<?php $__env->startSection('titolo', 'Dashboard.'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>




            </ol>
        </nav>




        <div class="card mb-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" class="pro-img">
                        <thead>
                            <tr>
                                <th> Product Name </th>
                                <th> Product Price </th>

                                <th> Product Category </th>
                                <th> Product Photo </th>
                                <th>Actions </th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($product->name); ?> </td>
                                    <td> <?php echo e($product->price); ?> </td>

                                    <td> <?php echo e($product->category->name); ?> </td>
                                    <td> <img src="<?php echo e($product->photo); ?>" width="50" height="50"></td>
                                    <td>
                                        <a href="<?php echo e(url('edit-product'.$product->id)); ?>" class="btn btn-outline-primary btn-sm"> Edit </a>
                                        |
                                        <a href="#" class="btn btn-success btn-sm " data-toggle="modal"
                                            data-target="#customerModal">Update Stock </a>
                                        |

                                        <a href="<?php echo e(URL::to('delete-product')); ?>/<?php echo e($product->id); ?>"
                                            class="btn btn-outline-danger btn-sm"> Delete </a>
                                    </td>

                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Add Customer Modal -->
            <div class="modal fade" id="customerModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add Product Stock</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form id='addCustomer'>
                                <input type="hidden" id="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group">
                                    <label for="name">Stock </label>
                                    <input type="text" class="form-control" id="name" name="name">
                                </div>


                                <input type="submit" value="Add" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templete.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/product/index.blade.php ENDPATH**/ ?>