<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <h2> PanelControl QuickBuyStore</h2>
    <div class="t py-3">
        <a href="<?php echo e(route('signout')); ?>" class="btn btn-sm  btn-success float-right">
            <i class="fas fa-user-plus">

            </i>
            Logout</a>
    </div>
</nav>
<!-- End of Topbar -->
<?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/templete/topbar.blade.php ENDPATH**/ ?>