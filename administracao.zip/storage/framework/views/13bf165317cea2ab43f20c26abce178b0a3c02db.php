<script src="<?php echo 'public/vendor/jquery/jquery.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/jquery-easing/jquery.easing.min.js'; ?> "></script>
<script src="<?php echo 'public/js/sb-admin-2.min.js'; ?> ?>"></script>
<script src="<?php echo 'public/vendor/bootstrap/js/bootstrap.bundle.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/jquery.dataTables.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/dataTables.bootstrap4.min.js'; ?> "></script>
<script src="<?php echo 'public/js/demo/datatables-demo.js'; ?>"></script>
<script src="<?php echo 'public/js/sweetalert2@11.js'; ?>"></script>
<script src="<?php echo 'https://unpkg.com/sweetalert/dist/sweetalert.min.js'; ?>"></script>
<?php if(session('success')): ?>
    <script>
        swal("<?php echo e(session('success')); ?>")
    </script>
<?php endif; ?>

<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/templete/script.blade.php ENDPATH**/ ?>