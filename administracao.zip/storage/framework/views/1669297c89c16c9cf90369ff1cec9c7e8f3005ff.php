<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <h2> PanelControl QuickBuyStore</h2>

</nav>
<!-- End of Topbar -->
<?php /**PATH E:\projectos\Programacao\Php\www\2021\2-ABR\administracao\resources\views/templete/topbar.blade.php ENDPATH**/ ?>