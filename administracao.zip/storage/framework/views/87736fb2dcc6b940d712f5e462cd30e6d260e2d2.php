<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">


    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(URL::to('/')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Home</span></a>
    </li>



    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
           aria-controls="collapseOne">
            <i class="fas fa-fw fa-cog"></i>
            <span>Teacher</span>
        </a>
        <div id="collapseOne" class="collapse" aria-labelledby="headingO" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">

                <a class="collapse-item" href="<?php echo e(URL::to('create-teacher')); ?>">Create Teacher</a>
                <a class="collapse-item" href="<?php echo e(URL::to('all-teacher')); ?>">All Teachers</a>
            </div>
        </div>
    </li>

</li>
<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTree" aria-expanded="true"
       aria-controls="collapseTree">
        <i class="fas fa-fw fa-cog"></i>
        <span>Student</span>
    </a>
    <div id="collapseTree" class="collapse" aria-labelledby="heading1" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">

            <a class="collapse-item" href="<?php echo e(URL::to('get-student-form')); ?>">Create Student</a>
            <a class="collapse-item" href="<?php echo e(URL::to('all-students')); ?>">All Students</a>
        </div>
    </div>
</li>
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFor" aria-expanded="true"
       aria-controls="collapseFor">
        <i class="fas fa-fw fa-cog"></i>
        <span>Activity</span>
    </a>
    <div id="collapseFor" class="collapse" aria-labelledby="heading2" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">

            <a class="collapse-item" href="<?php echo e(URL::to('get-activity-form')); ?>">Create Activity </a>
            <a class="collapse-item" href="<?php echo e(URL::to('all-activity')); ?>">All Activity</a>
        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/templete/sidebar.blade.php ENDPATH**/ ?>