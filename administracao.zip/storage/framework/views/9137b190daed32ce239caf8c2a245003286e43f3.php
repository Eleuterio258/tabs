<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('titolo'); ?></title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo 'public/vendor/fontawesome-free/css/all.min.css'; ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo 'public/css/sb-admin-2.min.css'; ?>" rel="stylesheet">
    <link href="<?php echo 'public/vendor/datatables/dataTables.bootstrap4.min.css'; ?>" rel="stylesheet">
    <link href="<?php echo 'public/css/app.css'; ?>" rel="stylesheet">

</head>
<?php /**PATH E:\projectos\Programacao\Php\www\2021\4-QuickBuyStore\administracao\resources\views/templete/header.blade.php ENDPATH**/ ?>