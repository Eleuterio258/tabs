<!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
<?php /**PATH E:\projectos\Programacao\Php\www\2021\2-ABR\administracao\resources\views/templete/button.blade.php ENDPATH**/ ?>