@extends('templete.app')
@section('titolo', 'Dashboard.')
@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ URL::to('/') }}">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Teacher</li>
        </ol>
    </nav>
    @if(Session::get('deleted'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert" id="gone">
        <strong> {{ Session::get('deleted') }} </strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    @if(Session::get('delete-failed'))
    <div class="alert alert-warning alert-dismissible fade show" role="alert" id="gone">
        <strong> {{ Session::get('delete-failed') }} </strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <div class="card mb-3">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th> Teacher Name </th>
                            <th> Teacher Photo </th>
                            <th>Actions </th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach($categories as $category)

                        <tr>
                            <td> {{ $category->name }} </td>
                            <td> <img src="{{ $category->icon }}" width="20" height="20"></td>
                            <td>
                                <a href="{{ URL::to('edit-teacher') }}/{{ $category->id }}" class="btn btn-outline-primary btn-sm"> Edit </a>
                                |
                                <a href="{{ URL::to('delete-teacher') }}/{{ $category->id }}" class="btn btn-outline-danger btn-sm" onclick="checkDelete()"> Delete </a>
                            </td>

                        </tr>


                        @endforeach



                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function checkDelete() {
        var check = confirm('Are you sure you want to Delete this?');
        if (check) {
            return true;
        }
        return false;
    }
</script>

@endsection
