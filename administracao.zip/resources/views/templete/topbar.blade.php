<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <h2> PanelControl QuickBuyStore</h2>
    <div class="t py-3">
        <a href="{{ route('signout') }}" class="btn btn-sm  btn-success float-right">
            <i class="fas fa-user-plus">

            </i>
            Logout</a>
    </div>
</nav>
<!-- End of Topbar -->
