<script src="<?php echo 'public/vendor/jquery/jquery.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/jquery-easing/jquery.easing.min.js'; ?> "></script>
<script src="<?php echo 'public/js/sb-admin-2.min.js'; ?> ?>"></script>
<script src="<?php echo 'public/vendor/bootstrap/js/bootstrap.bundle.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/jquery.dataTables.min.js'; ?>"></script>
<script src="<?php echo 'public/vendor/datatables/dataTables.bootstrap4.min.js'; ?> "></script>
<script src="<?php echo 'public/js/demo/datatables-demo.js'; ?>"></script>
<script src="<?php echo 'public/js/sweetalert2@11.js'; ?>"></script>
<script src="<?php echo 'https://unpkg.com/sweetalert/dist/sweetalert.min.js'; ?>"></script>
@if (session('success'))
    <script>
        swal("{{ session('success') }}")
    </script>
@endif

@yield('script')
