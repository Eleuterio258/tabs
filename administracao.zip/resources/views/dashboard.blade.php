@extends('templete.app')
@section('titolo', 'Dashboard.')
@section('content')
<div class="container-fluid">
    <div class="dashboard">

        <div id="painel">
            <i class="fa fa-user"></i>
            <p>
                <strong>Teacher</strong><br>
                <span>12</span>
            </p>
        </div>

        <div id="painel">
            <i class="fas fa-users"></i>
            <p>
                <strong>Student</strong><br>
                <span>12</span>
            </p>
        </div>

        <div id="painel">
            <i class="fas fa-boxes"></i>
            <p>
                <strong>Activities</strong><br>
                <span>12</span>
            </p>
        </div>

    </div>

</div>


@endsection
