@extends('templete.app')
@section('titolo', 'Dashboard.')
@section('content')
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ URL::to('/') }}">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Update product</li>
            </ol>
        </nav>


        <form action="{{ URL::to('post-product-edit-form') }}/{{ $product->id }}" method="post"
            enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="exampleInputEmail1"> Activity name </label>
                <input type="text" class="form-control" value="{{ $product->name }}" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="Enter product name" name="productName">
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1"> student number  </label>
                <input type="number" class="form-control" value="{{ $product->price }}" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="0.0" name="productPrice">
            </div>

           

            <div class="form-group">
                <label for="exampleInputEmail1"> Activity Detail </label>
                <textarea name="productDetail" id="editor1"> {!! $product->detail !!}</textarea>
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1"> Select product category </label>
                <select class="form-control" name="category">
                    <option> Select </option>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}" @if ($category->id == $product->category_id) selected @endif> {{ $category->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="exampleInputEmail1"> Product Photo </label>
                <input type="file" class="form-control" name="productPhoto" onchange="loadPhoto(event)">
            </div>

            <div class="form-group">
                <img id="photo" height="100" width="100">
            </div>

          
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
    <script>
        function loadPhoto(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('photo');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

@endsection
