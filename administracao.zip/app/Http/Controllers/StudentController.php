<?php

namespace App\Http\Controllers;

use App\Models\Slider;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentController extends Controller
{

    public function index()
    {

        if (Auth::check()) {
            $sliders = Slider::all();
            return view('student.index', compact('sliders'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function create()
    {
        if (Auth::check()) {
            return view('student.create');
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function store(Request $request)
    {
        $slider = new Slider();
        $slider->title = $request->input('sliderTitle');
        $slider->message = $request->input('sliderMessage');
        $slider->image_url = "";
        if ($slider->save()) {
            $photo = $request->file('sliderImage');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $slider = Slider::find($slider->id);
                        $slider->image_url = url('/') . '/public/' . $fileName;
                        $slider->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'Slider information inserted successfully!');
        }
        return redirect()->back()->with('failed', 'Slider information could not insert!');
    }




    public function edit($id)
    {

        if (Auth::check()) {
            $slider = Slider::find($id);
            return view('student.edit', compact('slider'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function update(Request $request, $id)
    {
        $slider = Slider::find($id);
        $slider->title = $request->input('sliderTitle');
        $slider->message = $request->input('sliderMessage');
        if ($slider->save()) {
            $photo = $request->file('sliderImage');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $slider = Slider::find($slider->id);
                        $slider->image_url = url('/') . '/public/' . $fileName;
                        $slider->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'Slider information updated successfully!');
        }
        return redirect()->back()->with('failed', 'Slider information could not update!');
    }


    public function destroy($id)
    {
        $slider = Slider::find($id);
        if ($slider->image_url) {


            $path = 'public' . $slider->image_url;
            if (File::exists($path)) {
                File::delete($path);
            }
            return redirect()->back()->with('deleted', 'Deleted successfully');
        }
        return redirect()->back()->with('delete-failed', 'Could not delete');
    }
}