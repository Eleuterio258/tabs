<?php

namespace App\Http\Controllers;

use File;
use App\Models\User;
use App\Models\Slider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{

    public function index()
    {

        if (Auth::check()) {
            $sliders = User::all();
            return view('slider.index', compact('sliders'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function create()
    {
        if (Auth::check()) {
            return view('slider.create');
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function store(Request $request)
    {
        $slider = new Slider();
        $slider->title = $request->input('sliderTitle');
        $slider->message = $request->input('sliderMessage');
        $slider->image_url = "";
        if ($slider->save()) {
            $photo = $request->file('sliderImage');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $slider = Slider::find($slider->id);
                        $slider->image_url = url('/') . '/public/' . $fileName;
                        $slider->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'Slider information inserted successfully!');
        }
        return redirect()->back()->with('failed', 'Slider information could not insert!');
    }




    public function edit($id)
    {

        if (Auth::check()) {
            $slider = Slider::find($id);
            return view('slider.edit', compact('slider'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function update(Request $request, $id)
    {
       
    }


    public function destroy($id)
    {
    }
}
