<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivitisController extends Controller
{

    public function index()
    {

        if (Auth::check()) {
            $products = Product::all();
            return view('activity.index', compact('products'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }

    public function create()
    {

        if (Auth::check()) {
            $categories = Category::all();
            return view('activity.create', compact('categories'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function store(Request $request)
    {
        $product = new Product();
        $product->name = $request->input('productName');
        $product->price = $request->input('productPrice');
        $product->discount = $request->input('productDiscount');
        $product->detail = $request->input('productDetail');
        $product->photo = "";
        $product->is_hot_product = $request->input('isHotProduct') ? true : false;
        $product->is_new_arrival = $request->input('isNewArrival') ? true : false;
        $product->category_id = $request->input('category');

        if ($product->save()) {
            $photo = $request->file('productPhoto');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $product = Product::find($product->id);
                        $product->photo = url('/') . '/public//uploads/' . $fileName;
                        $product->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'activity information inserted successfully!');
        }
        return redirect()->back()->with('failed', 'activity information could not be inserted!');
    }




    public function edit($id)
    {
        $product = Product::find($id);
        $categories = Category::all();
        return view('activity.edit', compact('product', 'categories'));
    }


    public function update(Request $request, $id)
    {
        $product = Product::find($id);
        $product->name = $request->input('productName');
        $product->price = $request->input('productPrice');
        $product->discount = $request->input('productDiscount');
        $product->detail = $request->input('productDetail');
        $product->is_hot_product = $request->input('isHotProduct') ? true : false;
        $product->is_new_arrival = $request->input('isNewArrival') ? true : false;
        $product->category_id = $request->input('category');
        if ($product->save()) {
            $photo = $request->file('productPhoto');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $product = Product::find($product->id);
                        $product->photo = url('/') . '/public//uploads/' . $fileName;
                        $product->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'activity information updated successfully!');
        }
        return redirect()->back()->with('failed', 'activity information could not update!');
    }

    public function destroy($id)
    {
        if (Product::destroy($id)) {
            return redirect()->back()->with('success', 'Deleted successfully');
        }
        return redirect()->back()->with('failed', 'Could not delete');
    }
}
