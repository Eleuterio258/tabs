<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TeacherController extends Controller
{

    public function index()
    {

        if (Auth::check()) {
            $categories = Category::all();
            return view('teacher.index', compact('categories'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function create()
    {
        if (Auth::check()) {
            $categories = Category::all();
            return view('teacher.create', compact('categories'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function store(Request $request)
    {
        $category = new Category();
        $category->name = $request->input('categoryName');
        $category->icon = "";
        //  $category->user_id = 0;
        if ($category->save()) {
            $photo = $request->file('categoryIcon');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $category = Category::find($category->id);
                        $category->icon = url('/') . '/public//uploads/' . $fileName;
                        $category->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'Saved successfully!');
        }
        return redirect()->back()->with('failed', 'Could not save!');
    }



    public function edit($id)
    {

        if (Auth::check()) {

            $category = Category::find($id);
            return view('teacher.edit', compact('category'));
        }

        return redirect("login")->withSuccess('You are not allowed to access');
    }


    public function update(Request $request, $id)
    {
        $category = Category::find($id);
        $category->name = $request->input('categoryName');
        $category->icon = "";
        if ($category->save()) {
            $photo = $request->file('categoryIcon');
            if ($photo != null) {
                $ext = $photo->getClientOriginalExtension();
                $fileName = rand(10000, 50000) . '.' . $ext;
                if ($ext == 'jpg' || $ext == 'png') {
                    if ($photo->move(public_path(), $fileName)) {
                        $category = Category::find($category->id);
                        $category->icon = url('/') . '/public//uploads/' . $fileName;
                        $category->save();
                    }
                }
            }
            return redirect()->back()->with('success', 'Updated successfully!');
        }
        return redirect()->back()->with('failed', 'Could not update!');
    }


    public function destroy($id)
    {
        if (Category::destroy($id)) {
            return redirect()->back()->with('deleted', 'Deleted successfully');
        }
        return redirect()->back()->with('delete-failed', 'Could not delete');
    }
}